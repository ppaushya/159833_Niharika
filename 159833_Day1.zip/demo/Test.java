package org.cap.demo;

public class Test {
	int count;
	char c;
	boolean flag;
	byte num;
	float pi;

	public static void main(String[] args) {
		int mynum=800;
		// TODO Auto-generated method stub
		Test obj=new Test();
		System.out.println(obj.count);
		System.out.println(obj.c);
		System.out.println(obj.flag);
		System.out.println(obj.num);
		System.out.println(obj.pi);
		System.out.println(mynum);

	}

}
