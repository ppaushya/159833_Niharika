package org.cap.demo;

public class SimpleInterest {
	int p;
	float t;
	float r;
	
	public void getData() {
		p=100;
		t=1.5f;
		r=0.2f;
			
	}
	public double calculate() {
		return p*t*r;
	}

	public static void main(String[] args) {
		
		SimpleInterest obj=new SimpleInterest();
		obj.getData();
		double amount=obj.calculate();
		System.out.println("output: "+amount);
	}

}
