package org.cap.demo;

import java.util.Scanner;

public class Scanner_Eg {
	long principal;
	float rateOfInterest;
	float years;
	
	public void getData() {
		Scanner scan= new Scanner(System.in);
		System.out.println("Enter principal amount:");
		principal=scan.nextLong();
		System.out.println("Enter rateOfInterest:");
		rateOfInterest=scan.nextFloat();
		System.out.println("Enter years:");
		years=scan.nextFloat();
		scan.close();
	}
	public double calculate() {
		return principal*rateOfInterest*years;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner_Eg obj=new Scanner_Eg();
		obj.getData();
		double amount=obj.calculate();
		System.out.println("output: "+amount);

	}

}
