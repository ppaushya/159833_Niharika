package org.cap.demo;

public class Final_Static {
	int i;
	static String s;
	
public void show() {
	System.out.println("Int:"+i);
	System.out.println("s: "+s);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Final_Static obj=new Final_Static();
		obj.i=15;
		s="Hi";
		System.out.println("Int:"+obj.i);
		System.out.println("s: "+s);
		obj.show();
		Final_Static obj1=new Final_Static();
		obj1.i=20;
		s="Hello";
		System.out.println("Int:"+obj1.i);
		System.out.println("s: "+s);
		obj1.show();
	}

}
