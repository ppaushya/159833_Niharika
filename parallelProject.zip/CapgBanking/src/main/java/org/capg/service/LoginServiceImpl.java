package org.capg.service;

import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;

import org.capg.dao.ILoginDao;
import org.capg.dao.LoginDaoImpl;
import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.LoginBean;
import org.capg.model.Transaction;

public class LoginServiceImpl implements ILoginService{

	private ILoginDao loginDao=new LoginDaoImpl();
	
	@Override
	public Customer isValidLogin(LoginBean loginBean) {
		/*if(loginBean.getUserName().equals("tom") && 
				loginBean.getUserPassword().equals("tom123")) {
			return true;
		}*/
		
		/*if(loginDao.isValidLogin(loginBean))
			return true;*/
		
		return loginDao.isValidLogin(loginBean);
	}

	@Override
	public boolean createCustomer(Customer customer) {
		
		return loginDao.createCustomer(customer);
	}

	@Override
	public Account createAccount(Account account) {
		
		return loginDao.createAccount(account);
	}

	@Override
	public LinkedList<Account> getAllAccount(int custId) {
		
		return loginDao.getAllAccount(custId);
	}

	@Override
	public boolean addTransaction(Transaction transaction) {
		return loginDao.addTransaction(transaction);
	}

	@Override
	public LinkedList<Account> getNotOfAllAccount(int custId) {
		return loginDao.getNotOfAllAccount(custId);
	}


	@Override
	public List<Transaction> getAllTransactions(int custId, LocalDate fromDate, LocalDate toDate) {
		return loginDao.getAllTransactions(custId,fromDate,toDate);
	}
}
