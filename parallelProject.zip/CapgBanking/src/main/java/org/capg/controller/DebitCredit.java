package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.dao.ILoginDao;
import org.capg.dao.LoginDaoImpl;
import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Customer;
import org.capg.model.LoginBean;
import org.capg.model.Transaction;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;


@WebServlet("/DebitCredit")
public class DebitCredit extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	ILoginService loginService=new LoginServiceImpl(); 
	
    public DebitCredit() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	HttpSession session=request.getSession();
		int custId=Integer.parseInt(session.getAttribute("custId").toString());
		
    	String accountNumber=request.getParameter("fromAccountNumber");
    	System.out.println(accountNumber);
		String transactionType=request.getParameter("transactionType");
		double amount=Double.parseDouble(request.getParameter("amount"));
		String description=request.getParameter("description");
		
		Transaction transaction=new Transaction();
		transaction.setAmount(amount);
		transaction.setDescription(description);
		transaction.setFromAccount(Integer.parseInt(accountNumber));
		transaction.setToAccount(0);
		transaction.setTransactionDate(LocalDate.now());
		transaction.setTransactionType(transactionType);
		transaction.setCustomerId(custId);
		
		if(loginService.addTransaction(transaction)) {
			System.out.println("transaction table updated...");
			response.sendRedirect("DebitCredit");
		}
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		
		HttpSession session=request.getSession();
		int custId=Integer.parseInt(session.getAttribute("custId").toString());
		System.out.println(custId);
		
		LinkedList<Account> accountList=loginService.getAllAccount(custId);
		
		out.print("<!DOCTYPE html>\r\n" + 
				"<html>\r\n" + 
				"<head>\r\n" + 
				"<meta charset=\"ISO-8859-1\">\r\n" + 
				"<title>Debit Credit</title>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"	<form method='post' action='DebitCredit'>\r\n" + 
				"		<table>\r\n" + 
				"			<tr>\r\n" + 
				"				<td>From Account:\r\n" + 
				"				<td><select name='fromAccountNumber'>\r\n" +
				"			" );
		for(Account acc:accountList) {
			System.out.println("hrlloe");
			out.print( 
		
				"						<option value='"+acc.getAccountNumber()+"'>"+acc.getAccountNumber()+"-"+acc.getAccountType()+"\r\n" );
		}
		out.print( 
				"				</select>\r\n" + 
				"			<tr>\r\n" + 
				"				<td>Transaction type:\r\n" + 
				"				<td><input type='radio' name='transactionType' value='debit'>Debit\r\n" + 
				"					<input type='radio' name='transactionType' value='credit'>Credit\r\n" + 
				"			<tr>\r\n" + 
				"				<td>Amount:\r\n" + 
				"				<td><input type='text' name='amount'>\r\n" + 
				"			<tr>\r\n" + 
				"				<td>Description:\r\n" + 
				"				<td><input type='text' name='description'>\r\n" + 
				"			<tr>\r\n" + 
				"				<td><input type='submit' value='Do transaction' name='transaction'>\r\n" + 
				"		</table>\r\n" +
				"		<div name='result'></div>" +
				"	</form>\r\n" + 
				"</body>\r\n" + 
				"</html>");
	}

}
