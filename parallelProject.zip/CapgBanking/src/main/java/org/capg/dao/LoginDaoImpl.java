package org.capg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Customer;
import org.capg.model.LoginBean;
import org.capg.model.Transaction;

public class LoginDaoImpl implements ILoginDao{

	@Override
	public Customer isValidLogin(LoginBean loginBean) {

		String sql="select * from customer where emailId=? and password=?";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {

			pst.setString(1, loginBean.getUserName());
			pst.setString(2, loginBean.getUserPassword());

			ResultSet rs=pst.executeQuery();

			if(rs.next()) {
				Customer customer=new Customer();
				customer.setCustomerId(rs.getInt(1));
				customer.setFirstName(rs.getString(2));
				customer.setLastName(rs.getString(3));
				return customer;
			}


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}


	private Connection getMysqlDbConnection() {

		Connection conn=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return conn;

	}


	@Override
	public boolean createCustomer(Customer customer) {
		int customerId=0;
		boolean flag=false;
		String sql="insert into customer(firstName,lastName,dateOfBirth, emailId,mobileNo,password)"+
				" values(?,?,?,?,?,?)";

		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {


			pst.setString(1, customer.getFirstName());
			pst.setString(2, customer.getLastName());
			pst.setDate(3, Date.valueOf(customer.getDateOfBirth()));
			pst.setString(4, customer.getEmailId());
			pst.setString(5,customer.getMobile());
			pst.setString(6,customer.getCustomerPwd());	

			int count=pst.executeUpdate();
			if(count>0)
				flag=true;

			if(flag) {
				String sqlMax="select max(customerId) from customer";
				try(PreparedStatement pst1=getMysqlDbConnection().prepareStatement(sqlMax)) {
					ResultSet rs= pst1.executeQuery();
					if(rs.next())
						customerId=rs.getInt(1);


					String sqlAdd="insert into address(addressline1,addressline2,city,state,pincode,customerId) values(?,?,?,?,?,?)";

					try(PreparedStatement pst2=getMysqlDbConnection().prepareStatement(sqlAdd)) {
						pst2.setString(1, customer.getAddress().getAddressLine1());
						pst2.setString(2, customer.getAddress().getAddressLine2());
						pst2.setString(3, customer.getAddress().getCity());
						pst2.setString(4, customer.getAddress().getState());
						pst2.setString(5, customer.getAddress().getPincode());
						pst2.setInt(6, customerId);

						int count1=pst2.executeUpdate();
						if(count1>0)
							flag=true;
						else
							flag=false;

					}


				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}else {
				flag=false;
			}


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



		return flag;
	}


	@Override
	public Account createAccount(Account account) {

		Long accountNo=null;

		String sqlaccNum="select max(accountNo) from account";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sqlaccNum)){
			ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				accountNo=Long.valueOf(rs.getInt(1));
				if(accountNo==0)
					accountNo=100000l;
				else
					accountNo+=1;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println(accountNo);
		account.setAccountNumber(accountNo);

		String sql="insert into account values(?,?,?,?,?,?)";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)){

			pst.setLong(1, accountNo);
			pst.setString(2, account.getAccountType().toString());
			pst.setDate(3,Date.valueOf(account.getOpeningDate()));
			pst.setDouble(4, account.getOpeningBalance());
			pst.setString(5, account.getDescription());
			pst.setInt(6, account.getCustomer().getCustomerId());
			int count=pst.executeUpdate();
			if(count>0)
				return account;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		return null;
	}


	@Override
	public LinkedList<Account> getAllAccount(int custId) {
		String sql="select * from account where customerId=?";
		LinkedList<Account> accountList=new LinkedList<>();
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {

			pst.setInt(1, custId);

			ResultSet rs=pst.executeQuery();

			while(rs.next()) {
				accountList.add(new Account(rs.getInt(1),AccountType.valueOf(rs.getString(2)),LocalDate.now(),rs.getDouble(4),rs.getString(5),rs.getInt(6)));
			}
			return accountList;

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}


	@Override
	public boolean addTransaction(Transaction transaction) {
		String sql="insert into transaction(transactionType,transactionDate,fromAccount,toAccount,amount,description,customerId) values(?,?,?,?,?,?,?)";
		int count=0;
		try(PreparedStatement statement=getMysqlDbConnection().prepareStatement(sql)) {

			statement.setString(1, transaction.getTransactionType());
			statement.setDate(2,Date.valueOf(transaction.getTransactionDate()));
			statement.setInt(3,transaction.getFromAccount());
			statement.setInt(4, transaction.getToAccount());
			statement.setDouble(5, transaction.getAmount());
			statement.setString(6, transaction.getDescription());
			statement.setInt(7, transaction.getCustomerId());
			

			count=statement.executeUpdate();

			if(count>0) {
				System.out.println("Transaction Completed Successfully!!!");
				return true;
			}

		}catch (SQLException e) {
			e.printStackTrace();
		}
		return false;

	}


	@Override
	public LinkedList<Account> getNotOfAllAccount(int custId) {
		String sql="select * from account where customerId<>?";
		LinkedList<Account> accountList=new LinkedList<>();
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {

			pst.setInt(1, custId);

			ResultSet rs=pst.executeQuery();

			while(rs.next()) {
				accountList.add(new Account(rs.getInt(1),AccountType.valueOf(rs.getString(2)),LocalDate.now(),rs.getDouble(4),rs.getString(5),rs.getInt(6)));
			}
			return accountList;

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}


	@Override
	public List<Transaction> getAllTransactions(int custId, LocalDate fromDate, LocalDate toDate) {
		String sql="select * from transaction where customerId=? and transactionDate between ? and ?";
		List<Transaction> transactions=new ArrayList<>();
		try {
			PreparedStatement statement=getMysqlDbConnection().prepareStatement(sql);
			statement.setInt(1, custId);
			statement.setDate(2, Date.valueOf(fromDate));
			statement.setDate(3, Date.valueOf(toDate));
			ResultSet rs=statement.executeQuery();
			
			while(rs.next()) {
				String[] str=rs.getString(2).split("-");
				
				transactions.add(new Transaction(rs.getInt(1),rs.getString(8),LocalDate.of(Integer.parseInt(str[0]), Integer.parseInt(str[1]), 
						Integer.parseInt(str[2])),rs.getInt(3),rs.getInt(4),rs.getDouble(5),rs.getString(6),rs.getInt(7)));
			}
			
			} catch (SQLException e) {
				e.printStackTrace();
			}
		
		return transactions;
	}

}
