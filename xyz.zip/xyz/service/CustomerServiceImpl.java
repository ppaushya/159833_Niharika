package org.xyz.service;

import java.time.LocalDate;
import java.util.List;

import org.xyz.dao.CustomerDaoImpl;
import org.xyz.dao.ICustomerDao;
import org.xyz.model.Customer;

public class CustomerServiceImpl implements ICustomerService{
	
	ICustomerDao customerDao=new CustomerDaoImpl();

	@Override
	public List<Customer> getCustomersList() {
		
	List<Customer> customers=customerDao.getCustomersList();
		return customers;
	}

	@Override
	public void createCustomer(Customer customer) {
		/*
		if(customer.getMobileNo().matches("[789]{1}[0-9]{9}"))  {
			if(customer.getDateOfBirth().isBefore(LocalDate.now()))*/
		System.out.println("customer");		
		customerDao.createCustomer(customer);
		/*}
			
		else
		System.out.println("Enter valid customer details");*/		
		
	}


}
