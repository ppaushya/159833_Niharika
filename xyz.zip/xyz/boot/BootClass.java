package org.xyz.boot;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.xyz.model.Customer;
import org.xyz.service.CustomerServiceImpl;
import org.xyz.service.ICustomerService;
import org.xyz.view.UserInteraction;

import util.Utility;

public class BootClass {

public static void main(String[] args) {
	
	Scanner scanner=new Scanner(System.in);
	UserInteraction userInteraction=new UserInteraction();
	ICustomerService customerService=new CustomerServiceImpl();
	String opt = null;
	do {
		
	
	System.out.println("Enter your option");
	System.out.println("1.create customer");
	System.out.println("2.List customers");
	
	int choice=scanner.nextInt();
	
	switch(choice) {
	
	case 1:
		
		Customer customer=userInteraction.getCustomerDetails();	
		//System.out.println(customer);
		customerService.createCustomer(customer);
		System.out.println("do u want to comtinue[y or n]");
		opt=scanner.next();
		break;
	
	case 2:
		List<Customer> customers=customerService.getCustomersList();
		userInteraction.printCustomers(customers);
		break;
	}
	
	}while(opt.charAt(0)=='y');
	
	
	
	}

}
