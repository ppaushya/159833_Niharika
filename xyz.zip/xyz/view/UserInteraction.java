package org.xyz.view;

import java.util.List;

import org.xyz.model.Customer;

import util.Utility;

public class UserInteraction {
	

		
	public Customer getCustomerDetails() {
		
		Customer customer=new Customer();
		
		customer.setCustomerId(Utility.generateNumber());
		customer.setFirstName(Utility.promptFirstName());
		customer.setLastName(Utility.promptLastName());
		customer.setEmailId(Utility.promptEmailId());
		customer.setMobileNo(Utility.promptMobileNo());
		customer.setDateOfBirth(Utility.promptDate());
		customer.setAddress(Utility.promptAddress());
		return customer;
	}

	public void printCustomers(List<Customer> customers) {
		System.out.println("List of customers:");
		System.out.println("CustomerId\tCustomerName\tMobileNumber\tEmailId");
		for(Customer customer:customers) {
			System.out.println(customer.getCustomerId()+"\t"+customer.getFirstName()+customer.getLastName()+"\t"+customer.getMobileNo()+"\t"+customer.getEmailId());
		
		}
			
	
	}
		
		
		


}
