package org.capg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.capg.model.Account;
import org.capg.model.Address;
import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.capg.util.Utility;

public class CustomerJdbcImpl implements ICustomerDao{

	@Override
	public List<Customer> getAllCustomers() {
		
		return null;
	}

	@Override
	public void createCustomer(Customer customer) {
     
		String sql="insert into customer(firstName,LastName,dateOfBirth,emailId,mobile) values(?,?,?,?,?)";
		String sql1="insert into address values(?,?,?,?,?,?)";
		String sql2="select max(customerId) from customer";
		
		Address address=new Address();
		int count=0;
		int count1=0;
		int custId = 0;
		try(PreparedStatement statement=getDbConnection().prepareStatement(sql)) {

			//statement.setInt(1, Utility.generateNumber());
			statement.setString(1, customer.getFirstName());
			statement.setString(2, customer.getLastName());
			statement.setDate(3,java.sql.Date.valueOf(customer.getDateOfBirth()));
			statement.setString(4, customer.getEmailId());
			statement.setString(5, customer.getMobile());
			
			count=statement.executeUpdate();
			
			}catch (SQLException e) {
			e.printStackTrace();
			}
		
		try(PreparedStatement statement2=getDbConnection().prepareStatement(sql2)) {
			
			ResultSet rs=statement2.executeQuery();
			
			if(rs.next()) {
				custId=rs.getInt(1);
			}
			
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		try(PreparedStatement statement1=getDbConnection().prepareStatement(sql1)) {
			
			statement1.setInt(1, custId);
			statement1.setString(2, customer.getAddress().getAddressLine1());
			statement1.setString(3, customer.getAddress().getAddressLine2());
			statement1.setString(4, customer.getAddress().getCity());
			statement1.setString(5,customer.getAddress().getState());
			statement1.setString(6, customer.getAddress().getPincode());
			
			count1=statement1.executeUpdate();
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			
			if(count>0) {
				if(count1>0) {
					System.out.println("Insertion done!");	
				}
				
						
			}
	}
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}

	@Override
	public void addAccount(Account account, Customer cust) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Transaction> getAllTransactions() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addTransaction(Transaction transaction1) {
		// TODO Auto-generated method stub
		
	}

}
