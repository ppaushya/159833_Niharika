package org.cap.demo;

public class SwitchLongShort {

	public static void main(String[] args) {
		short l=2200;
		switch(l) {
		case 4561:{
			System.out.println("one");
			System.out.println("Block1");
			break;
		}
		default:{
			System.out.println("Block default");
			break;
		}
		case 7856:{
			System.out.println("none");
			System.out.println("Block2");
			break;
		}
		case 2200:{
			System.out.println("true");
			System.out.println("Block");
			break;
		}
	}
long ln=1231456;
		
	/*	switch(ln) {
		case 124562:{
			System.out.println("one");
			System.out.println("Block1");
			break;
		}
		default:{
			System.out.println("Block default");
			break;
		}
		case 511235:{
			System.out.println("two");
			System.out.println("Block2");
			break;
		}
		case 1231456:{
			System.out.println("matched");
			System.out.println("Block");
			break;
		}
	}*/

	}

}
