package org.cap.demo;

public class While_Even {

	public static void main(String[] args) {
		int num=2;
		int sum=0;
		do {
			
			System.out.println(num);
			//sum=sum+num;
			num+=2;
		}
		while(num<=100);
		//System.out.println("sum of all"+sum);
			

	}

}
