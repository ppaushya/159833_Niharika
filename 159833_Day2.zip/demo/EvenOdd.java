package org.cap.demo;

import java.util.Scanner;

public class EvenOdd {
	
	public int getNumber() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number:");
		int number=sc.nextInt();
		sc.close();
		return number;
	}

	public static void main(String[] args) {
		EvenOdd obj=new EvenOdd();
		int val=obj.getNumber();
		int c1=3;
		int newline=0;
		
		for(int i=1;i<val;i++) {
			if(i%2==0) {
				while(c1>0) {
					if(i<val)
					System.out.print(i+"\t");
					c1--;
					i+=2;
					newline++;
				}
				c1=3;
				i-=2;
				if(newline%12==0)
					System.out.println();
			}
			else {
				while(c1>0) {
					if(i<val)
					System.out.print(i+"\t");
					c1--;
					i+=2;
					newline++;
				}
				c1=3;
				i-=6;
				if(newline%12==0)
					System.out.println();
			}
			
				
			}
			
		}
}
