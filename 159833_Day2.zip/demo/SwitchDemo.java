package org.cap.demo;

public class SwitchDemo {

	public static void main(String[] args) {
		String string="One";
		
		switch(string) {
		case "two":{
			System.out.println("two");
			System.out.println("Block1");
			break;
		}
		default:{
			System.out.println("Block default");
			break;
		}
		case "none":{
			System.out.println("none");
			System.out.println("Block2");
			break;
		}
		case "One":{
			System.out.println("true");
			System.out.println("Block");
			break;
		}
	}
char chr='&';
		
		switch(chr) {
		case 'a':{
			System.out.println("two");
			System.out.println("Block1");
			break;
		}
		default:{
			System.out.println("Block default");
			break;
		}
		case 5:{
			System.out.println("none");
			System.out.println("Block2");
			break;
		}
		case '&':{
			System.out.println("matched");
			System.out.println("Block");
			break;
		}
	}
	}
}