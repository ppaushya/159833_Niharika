package org.cap.demo;

import java.util.Scanner;

public class Public {
	String productName;
	int productId;
	int quantity;
	long price;
	double discount;
	double tax;
	
	public void getProductDetails() {
	
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter product name:");
		productName=scan.next();
		System.out.println("Enter product Id:");
		productId=scan.nextInt();
		System.out.println("Enter product quantity:");
		quantity=scan.nextInt();
		System.out.println("Enter product price:");
		price=scan.nextLong();
		System.out.println("Enter product dicount:");
		discount=scan.nextDouble();
		scan.close();
		
	}
	public double calculateDiscount() {
		double disc=discount*(price*quantity)/100;
		return disc;
	}
	public void calculateTax() {
		if (discount>=90) {
			tax=0.01*(price*quantity);
		}
		else if(discount>=80)
			tax=0.12*(price*quantity);
		else if(discount>=60)
			tax=0.20*(price*quantity);
		else if(discount>=50)
			tax=0.25*(price*quantity);
		else
			tax=0.40*(price*quantity);
			
	}
	public void findPrice() {
		double total=(price*quantity)+tax-calculateDiscount();
		System.out.println("Total Amount To be paid:"+total);
	}

	public static void main(String[] args) {
		Public obj=new Public();
		obj.getProductDetails();
		obj.calculateTax();
		obj.findPrice();
		
	}
}
