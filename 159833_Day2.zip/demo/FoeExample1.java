package org.cap.loop.demo;

public class FoeExample1 {

	public static void main(String[] args) {
		int c=0;
		for(int i=2;i<=100;) {
			for(int j=1;j<6;j++) {
				if(c%6==0) {
				System.out.print(i+"\t");
				
				i+=2;}
				else {
					System.out.print("*\t");
					i+=2;
				}
				c++;
			}
			if(c==25) {
				c=0;
			}
			System.out.println();
			
		}
	}

}
