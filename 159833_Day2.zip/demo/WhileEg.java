package org.cap.demo;

public class WhileEg {

	public static void main(String[] args) {
	int num=1;
	int count=5;
	
	while(num<=100) {
		while(count>0) {
			if(num%2==0) {
				System.out.print(num+",");
			
			count--;}
			num++;
		}
		count=5;
		System.out.println();
	}
	int num1=1;
	int count1=5;
	while(num1<=100) {
		if(num1%2==0) {
			System.out.print(num1+",");
			count1--;
		}
		num1++;
		if(count1==0) {
			count1=5;
			System.out.println();
		}
	}

	}

}
