package org.cap.demo;

public class PrimeNumber {
	
	public boolean isPrime(int i) {
		int c=0;
			for(int j=1;j<1000;j++) {
				if(i%j==0)
					c++;
			}
			if(c==2) {
				return true;
			}
			else 
				return false;
		}


	public static void main(String[] args) {
		PrimeNumber prime=new PrimeNumber();
		for(int i=1;i<=1000;i++) {
			boolean ans=prime.isPrime(i);
			if(ans) {
				System.out.println(i);
			}
				
		}

		
	}
}
