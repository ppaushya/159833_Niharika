package org.cap.demo;

import java.util.Scanner;

public class StringFormat {
	String str;
	public void getString() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter String:");
		str=sc.next();
		sc.close();
	}

	public static void main(String[] args) {
		StringFormat sf=new StringFormat();
		sf.getString();
		//System.out.println(sf.str);
		for(int i=0;i<sf.str.length();i++) {
			for(int j=0;j<=i;j++) {
				System.out.print(sf.str.charAt(j));
			}
			System.out.println();
		}

	}

}
