package org.cap.demo;

public class AmstrongNumber {
	
	public boolean isArmstrong(int num) {
		int k=num;
		int sum=0;
		int r=0;
		do{
			r=num%10;
			num=num/10;
			sum=sum+(r*r*r);
		}while(num>0); 
		if(k==sum)
			return true;
		else
			return false;
	}

	public static void main(String[] args) {
		AmstrongNumber obj=new AmstrongNumber();
		for(int i=1;i<1000;i++) {
			boolean ans=obj.isArmstrong(i);
			if(ans) {
				System.out.println(i);
			}
		}
	}

}
