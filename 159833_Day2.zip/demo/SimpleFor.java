package org.cap.loop.demo;

public class SimpleFor {

	public static void main(String[] args) {
		int c=1;
		for(int i=1;i<5;i++) {
			for(int j=i;j>0;j--) {
				
				System.out.print(c+"\t");
				c++;
			}
			System.out.println();
		}

	}

}
