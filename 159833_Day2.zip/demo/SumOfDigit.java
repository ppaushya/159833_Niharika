package org.cap.demo;

import java.util.Scanner;

public class SumOfDigit {
	int num;
	public void getNumber() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number:");
		num=sc.nextInt();
		sc.close();
	}

	public static void main(String[] args) {
		SumOfDigit obj=new SumOfDigit();
		obj.getNumber();
		
		int sum=0;
		int r=0;
		do{
			r=obj.num%10;
			obj.num=obj.num/10;
			sum=sum+r;
		}while(r>0); 
		System.out.println(sum);
	}

}
