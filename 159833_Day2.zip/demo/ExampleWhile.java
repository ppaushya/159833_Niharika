package org.cap.demo;

public class ExampleWhile {

	public static void main(String[] args) {
		
		/*int num=1;
		int count=5;
		
		while(num<=100) {
						while()
			while(count>0) {
				
				if(num%2==0) {
					System.out.print(num+" ");
				
				count--;}
				num++;
				
			}
			count=5;
			System.out.println();
		}*/
		int count=0;
		int c=0;
		for(int i=1;i<100;i++) {
			
			
			if(i%2==0) {
				
				if(c%6==0) {
					System.out.print(i+" ");
					c++;
				}
				else {
					System.out.print("* ");
				}
			}
			if(i%10==0) {
				System.out.println();
				
			}
				
		}
		
		
		
		
		
	}
			
		
}
