package org.cap.demo;

import java.util.Scanner;

public class SortStringArray {
	String[] mystr;
	
	public void acceptString(int size) {
		Scanner sc=new Scanner(System.in);
		mystr=new String[size];
		System.out.println("Enter "+size+" elements");
		for(int i=0;i<size;i++) {
			mystr[i]=sc.nextLine();
		}
		sc.close();
	}
	public void sortedArray(String[] mystr) {
		String t=null;
		for(int i=0;i<mystr.length;i++) {
			for(int j=0;j<mystr.length;j++) {
				int k=mystr[i].compareTo(mystr[j]);
				if(k<=1) {
					t=mystr[i];
					mystr[i]=mystr[j];
					mystr[j]=t;
				}
			}
		}
		System.out.println("Sorted String Array is:");
		for(int i=0;i<mystr.length;i++) {
			System.out.println(mystr[i]);
		}
	}

	public static void main(String[] args) {
		SortStringArray obj=new SortStringArray();
		obj.acceptString(5);
		obj.sortedArray(obj.mystr);
		

	}

}
