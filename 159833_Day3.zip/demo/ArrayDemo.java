package org.cap.demo;

public class ArrayDemo {

	public static void main(String[] args) {
		//int[] num=new int[10];
		double pi=3.14;
		int num[]= {1,9,43,(int)pi};
		for(int i=0;i<4;i++) {
			System.out.println(num[i]);
		}
		System.out.println("size of array:"+num.length);
	}

}
