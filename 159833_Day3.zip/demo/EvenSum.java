package org.cap.demo;

import java.util.Scanner;

public class EvenSum {
	int[] myArr;
	public void getArrayElements(int size) {
		Scanner sc=new Scanner(System.in);
		myArr=new int[size];
		System.out.println("Enter "+size+" elements");
		for(int i=0;i<size;i++) {
			myArr[i]=sc.nextInt();
		}
		sc.close();
	}
	
	public void printEven() {
		System.out.println("Even Numbers:");
		for(int i=0;i<myArr.length;i++) {
			if(myArr[i]%2==0) {
				System.out.println(myArr[i]);
			}
		}
	}
		public void printEvenSum() {
			int sum=0;
			for(int i=0;i<myArr.length;i++) {
				if(myArr[i]%2==0) {
					sum=sum+myArr[i];
				}
			}
			System.out.println("Sum of Even Numbers "+sum);
	}

	public static void main(String[] args) {
		EvenSum obj=new EvenSum();
		obj.getArrayElements(5);
		obj.printEven();
		obj.printEvenSum();

	}

}
