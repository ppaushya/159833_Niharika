package org.cap.demo;

import java.util.Scanner;

public class RowMinimum {
	public void sortArray(int c[][])
	{
		int i,j,k,temp;
		
		int d[][]=new int[c.length][c[0].length];
		
		for(k=0;k<c.length;k++)
		{
			for(i=0;i<c[0].length;i++)
			{
				for(j=i+1;j<c[0].length;j++)
				{
					if(c[k][i]>c[k][j])
					{
						temp=c[k][i];
						c[k][i]=c[k][j];
						c[k][j]=temp;
					}
				}
			}
		}
				
	}
	
	
	public void findsmallest(int t[][])
	{
		
		
		int flag=0;
		
		sortArray(t);
		
		for(int i=0;i<t.length;i++)
		{
			
			for(int j=0;j<t[0].length-1;j++)
			{
				if(t[i][j+1]-t[i][j]>1)
				{
					System.out.println(t[i][j]+1);
					flag=1;
					break;
				}
			}
			if(flag==0)
			{
				System.out.println(t[i][t[0].length-1]+1);
			}
			flag=0;
		}
		
		
	}
	
	
	public static void main(String[] args) {
	
		int a[][]= {{10,20,30},{1,7,8},{100,1,0}};
		
		RowMinimum obj=new RowMinimum();
		
		obj.findsmallest(a);
		
	
	}
}
