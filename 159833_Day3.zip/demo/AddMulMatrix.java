package org.cap.demo;

import java.util.Scanner;

public class AddMulMatrix {
	int[][] a;int[][] b;
	
	public int[][] getArrayElements(int row,int col) {
		Scanner sc=new Scanner(System.in);
		int [][]a=new int[row][col];
		System.out.println("Enter elements");
		for(int i=0;i<row;i++) {
			for(int j=0;j<col;j++)
			a[i][j]=sc.nextInt();
		}
		return a;
	}
	
	public void addMatrix(int[][] a,int[][] b) {
		System.out.println("added matrix is:");
		int[][] add=new int[a.length][a[0].length];
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a[0].length;j++) {
				add[i][j]=a[i][j]+b[i][j];
				System.out.print(add[i][j]+"\t");
			}
			System.out.println();
		}
	}
	
	public void mulMatrix(int[][] a,int[][] b) {
		System.out.println("multiplied matrix is:");
		if(a[0].length==b.length) {
			int[][] mul=new int[a.length][b[0].length];
			int r2,c2;
			
			for(int r1=0,c1=0;r1<a.length;r1++) {
				for(c2=0;c2<b[0].length;c2++) {
					for(r2=0;r2<b.length;r2++) {
						mul[r1][c2]+=a[r1][c1]*b[r2][c2];
						c1++;
						
					}			
					System.out.print(mul[r1][c2]+"\t");
					c1=0;
					
				}
				System.out.println();
				}
				
				
		}
		
	}
	

	public static void main(String[] args) {
		AddMulMatrix am=new AddMulMatrix();
		am.a=am.getArrayElements(2, 3);
		am.b=am.getArrayElements(3, 2);
		//am.addMatrix(am.a,am.b);
		am.mulMatrix(am.a, am.b);

	}

}
