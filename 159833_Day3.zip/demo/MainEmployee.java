package org.cap.demo;

public class MainEmployee {
	Employee[] emp;
	public void acceptEmployees(int size) {
		emp=new Employee[size];
		for(int i=0;i<size;i++) {
			emp[i]=new Employee();
			emp[i].getDetails();
		}
	}
	
	public void printEmployees() {
		for(int i=0;i<emp.length;i++) {
			emp[i].printDetails();
		}
	}
	public void sortDetails() {
		for(int i=0;i<emp.length;i++) {
			Employee y;
			for(int j=i+1;j<emp.length;j++) {
				if(emp[i].empId<emp[j].empId) {
					y=emp[i];
					emp[i]=emp[j];
					emp[j]=y;
				}
			}
			
		}
	}

	public static void main(String[] args) {
		MainEmployee me=new MainEmployee();
		me.acceptEmployees(2);
		me.printEmployees();
		me.sortDetails();
		me.printEmployees();
	}

}
