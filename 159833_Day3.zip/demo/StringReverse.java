package org.cap.demo;

import java.util.Scanner;

public class StringReverse {
	String[] mystr;
	public void acceptString(int size) {
		Scanner sc=new Scanner(System.in);
		mystr=new String[size];
		System.out.println("Enter "+size+" elements");
		for(int i=0;i<size;i++) {
			mystr[i]=sc.nextLine();
		}
		sc.close();
	}
	public void reverse(String[] mystr) {
		String t=null;
		for(int i=0,e=mystr.length-1;i<=mystr.length/2;) {
			t=mystr[i];
			mystr[i]=mystr[e];
			mystr[e]=t;
			e--;i++;
			if(e==i)
				break;
		}
		System.out.println();
		System.out.println("Reverse string array is:");
		for(int i=0;i<mystr.length;i++) {
			System.out.println(mystr[i]+"\t");
		}
	}
	public static void main(String[] args) {
		StringReverse sr=new StringReverse();
		sr.acceptString(5);
		sr.reverse(sr.mystr);
	}
}
