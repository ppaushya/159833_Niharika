package org.cap.demo;

import java.util.Scanner;

public class Employee {
	Scanner sc=new Scanner(System.in);
	int empId;
	String firstName;
	String lastName;
	byte age;
	int salary;
	 public void getDetails() {
		 System.out.println("Enter Employee Id:");
		 empId=sc.nextInt();
		 System.out.println("Enter Employee First Name:");
		 firstName=sc.next();
		 System.out.println("Enter Employee Last Name:");
		 lastName=sc.next();
		 System.out.println("Enter Employee age:");
		 age=sc.nextByte();
		 System.out.println("Enter Employee salary:");
		 salary=sc.nextInt();
		 
	 }
	 public void printDetails() {
		 System.out.println(empId+"\t"+firstName+"\t"+lastName+"\t"+age+"\t"+salary);
	 }
	
}
