package org.cap.demo;

import java.util.Scanner;

public class LowerTriangle {
Scanner sc=new Scanner(System.in);
	
	int[][] a;
	
	
	public void getMatrix() {
		
		System.out.println("enter size:");
		int s=sc.nextInt();	
		a=new int[s][s];
		System.out.println("enter values");
		for(int i=0;i<s;i++) {
			for(int j=0;j<s;j++) {
				
				a[i][j]=sc.nextInt();
			}
		}
	}
	
	public void lowerTriang() {
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a.length;j++) {
				if(i>=j)
					System.out.print(a[i][j]+"\t");
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		LowerTriangle obj=new LowerTriangle();
		obj.getMatrix();
		obj.lowerTriang();

	}

}
