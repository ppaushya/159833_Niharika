package org.cap.demo;

import java.util.Scanner;

public class SmallestElement {
	
	int[] myArr;
	public void getArrayElements(int size) {
		Scanner sc=new Scanner(System.in);
		myArr=new int[size];
		System.out.println("Enter "+size+" elements");
		for(int i=0;i<size;i++) {
			myArr[i]=sc.nextInt();
		}
		sc.close();
	}
	public void sortArray(int[] arr) {
		int t=0;
		for(int i=0;i<arr.length;i++) {
			for(int j=i;j<arr.length;j++) {
				if(arr[i]>arr[j]) {
					t=arr[i];
					arr[i]=arr[j];
					arr[j]=t;
				}
			}
		}
	}

	public void findSmallestElement(int[] arr) {
		
			int a=0;
			if(arr[1]-arr[0]>1) {
				System.out.println(arr[0]+1);
				a++;
			}
			else {
				for(int i=1;i<arr.length-1;i++) {
					if(arr[i+1]-arr[i]>1 ) {
						System.out.println(arr[i]+1);
						a++;
						break;
					}
				}
				if(a==0)
					System.out.println(arr[arr.length-1]+1);
			}
			
		
		
		
	}
	
	public static void main(String[] args) {
		SmallestElement sm=new SmallestElement();
		sm.getArrayElements(5);
		sm.sortArray(sm.myArr);
		sm.findSmallestElement(sm.myArr);
		//System.out.println(r);

	}

}
