package org.cap.demo;

import java.util.Scanner;

public class StrArray {
	String[] mystr;
	public void acceptString(int size) {
		Scanner sc=new Scanner(System.in);
		mystr=new String[size];
		System.out.println("Enter "+size+" elements");
		for(int i=0;i<size;i++) {
			mystr[i]=sc.nextLine();
		}
		sc.close();
	}
	public void printString() {
		for(int i=0;i<mystr.length;i++) {
			System.out.println(mystr[i]);
		}
	}

	public static void main(String[] args) {
		StrArray obj=new StrArray();
		obj.acceptString(5);
		obj.printString();
	}

}
