package org.cap.demo;

import java.util.Scanner;

public class ArrayExample {
	int[] myArr;
	public void getArrayElements(int size) {
		Scanner sc=new Scanner(System.in);
		myArr=new int[size];
		System.out.println("Enter "+size+" elements");
		for(int i=0;i<size;i++) {
			myArr[i]=sc.nextInt();
		}
		sc.close();
	}
	public void printArray() {
		System.out.println("Actual array");
		for(int i=0;i<myArr.length;i++) {
			System.out.print(myArr[i]+"\t");
		}
		System.out.println();
	}
	
	public void printReverseArray() {
		System.out.println("reverse array");
		for(int i=myArr.length-1;i>=0;i--) {
			System.out.print(myArr[i]+"\t");
		}
		
	}
	
	public void storeReverseArray() {
		int t=0;
		for(int i=0,e=myArr.length-1;i<myArr.length/2;) {
			t=myArr[i];
			myArr[i]=myArr[e];
			myArr[e]=t;
			e--;i++;
			if(e==i)
				break;
		}
		System.out.println();
		System.out.println("Reverse stored array");
		for(int i=0;i<myArr.length;i++) {
			System.out.print(myArr[i]+"\t");
		}
				
	}
	
	public static void main(String[] args) {
		ArrayExample obj=new ArrayExample();
		obj.getArrayElements(10);
		obj.printArray();
		obj.printReverseArray();
		obj.storeReverseArray();	
	}

}
