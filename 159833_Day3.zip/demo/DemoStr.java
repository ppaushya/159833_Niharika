package org.cap.demo;

public class DemoStr {

	public static void main(String[] args) {
	String str="hi";
	String str1=new String("hiytf");
	String str2="hi";
	System.out.println(str);
	System.out.println(str1);
	System.out.println(str.hashCode());
	System.out.println(str2.hashCode());
	}

}
