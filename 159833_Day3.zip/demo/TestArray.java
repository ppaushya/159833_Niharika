package org.cap.demo;

public class TestArray {
	public void printData(int ... arr) {
		for(int value:arr)
			System.out.println(value);
	}
	public static void main(String[] args) {
		TestArray obj=new TestArray();
		int[] myArr= {1,2,5,8};
		obj.printData(myArr);
	}

}
