package org.cap.demo;

import java.util.Scanner;

public class Sort {
	int[] myArr;
	public void getArrayElements(int size) {
		Scanner sc=new Scanner(System.in);
		myArr=new int[size];
		System.out.println("Enter "+size+" elements");
		for(int i=0;i<size;i++) {
			myArr[i]=sc.nextInt();
		}
		sc.close();
	}
	public void sortedAscendingArray() {
		int t=0;
		for(int i=0;i<myArr.length;i++) {
			for(int j=i;j<myArr.length;j++) {
				if(myArr[i]>myArr[j]) {
					t=myArr[i];
					myArr[i]=myArr[j];
					myArr[j]=t;
				}
			}
		}
		System.out.println("Sorted ascending array");
		for(int i=0;i<myArr.length;i++) {
			System.out.print(myArr[i]+"\t");
		}
		System.out.println();
	}
	public void sortedDescendingArray() {
		int t=0;
		for(int i=0;i<myArr.length;i++) {
			for(int j=i;j<myArr.length;j++) {
				if(myArr[i]<myArr[j]) {
					t=myArr[i];
					myArr[i]=myArr[j];
					myArr[j]=t;
				}
			}
		}
		System.out.println("Sorted descending array");
		for(int i=0;i<myArr.length;i++) {
			System.out.print(myArr[i]+"\t");
		}
		System.out.println();
	}

	public static void main(String[] args) {
		Sort obj=new Sort();
		obj.getArrayElements(10);
		obj.sortedDescendingArray();
		obj.sortedAscendingArray();

	}

}
