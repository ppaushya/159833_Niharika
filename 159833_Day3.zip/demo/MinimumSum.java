package org.cap.demo;

import java.util.Scanner;

public class MinimumSum {
	
	Scanner sc=new Scanner(System.in);
	
	int[][] a;
	
	
	public void getMatrix() {
		
		System.out.println("enter row size:");
		int r=sc.nextInt();	
		System.out.println("enter column size:");
		int k=sc.nextInt();	
		a=new int[r][k];
		System.out.println("enter values");
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a[0].length;j++) {
				
				a[i][j]=sc.nextInt();
			}
		}
	}
	public void calcMinSum() {
		int[] sum=new int[a.length];
		for(int i=0;i<a.length;i++) {
			
			for(int j=0;j<a[0].length;j++) {
				sum[i]+=a[i][j];
			}
		}
		int t=sum[0];
		
		int l=0;
		for(int i=0;i<a.length;i++) {
			if(sum[i]<=t) {
				t=sum[i];
				l=i;
			}
				
			
		}
		for(int i=l,j=0;j<a[0].length;j++) {
			System.out.print(a[i][j]+"\t");
		}
		
	}

	public static void main(String[] args) {
		MinimumSum ms=new MinimumSum();
		ms.getMatrix();
		ms.calcMinSum();
		

	}

}
