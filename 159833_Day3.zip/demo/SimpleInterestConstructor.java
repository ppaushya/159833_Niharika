package org.cap.demo;

public class SimpleInterestConstructor {
	int principal;
	float rateOfInterest;
	int years;
	
	public SimpleInterestConstructor() {
		super();
		this.principal = 100;
		this.rateOfInterest = 0.1f;
		this.years = 1;
	}
	public float calcSimpInt() {
		return principal*rateOfInterest*years/100;
	}
	public float calcSimpInt(int p) {
		return p*rateOfInterest*years/100;
	}
	public float calcSimpInt(int p,float r) {
		return p*r*years/100;
	}
	public float calcSimpInt(int p,float r,int y) {
		return p*r*y/100;
	}

	public static void main(String[] args) {
		SimpleInterestConstructor obj=new SimpleInterestConstructor();
		float r1=obj.calcSimpInt(5000);
		//float r2=obj.calcSimpInt(500);
		System.out.println(r1);
	}

}
