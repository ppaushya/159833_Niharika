package org.cap.demo;

public class TwoDimensional {

	public static void main(String[] args) {
		int[][] arr=new int[3][2];
		arr[0][0]=12;
		arr[0][1]=24;
		
		arr[1][0]=36;
		arr[1][1]=48;
		
		arr[2][0]=60;
		arr[2][1]=72;
		
		for(int i=0;i<3;i++) {
			for(int j=0;j<2;j++) {
				System.out.print(arr[i][j]+"\t");
			}
			System.out.println();
		}
	}

}
