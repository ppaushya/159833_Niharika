package org.cap.demo;

import java.util.Scanner;

public class Biggestsmallest {
	
	int[] myArr;
	public void getArrayElements(int size) {
		Scanner sc=new Scanner(System.in);
		myArr=new int[size];
		System.out.println("Enter "+size+" elements");
		for(int i=0;i<size;i++) {
			myArr[i]=sc.nextInt();
		}
		sc.close();
	}
	public void biggestNumber() {
		int t=myArr[0];
		for(int i=0,j=0;i<myArr.length;i++) {
			
				if(myArr[i]>t) {
					t=myArr[i];
					
				}
			}
		System.out.println("Biggest Number is "+t);
	}
	public void smallestNumber() {
		int t=myArr[0];
		for(int i=0,j=0;i<myArr.length;i++) {
			
				if(myArr[i]<t) {
					t=myArr[i];
					
				}
			}
		System.out.println("Smallest Number is "+t);
	}

	public static void main(String[] args) {
		Biggestsmallest obj=new Biggestsmallest();
		obj.getArrayElements(5);
		obj.biggestNumber();
		obj.smallestNumber();

	}

}
