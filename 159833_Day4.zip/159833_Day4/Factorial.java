package org.cap.demo;

public class Factorial {
	
	public int FirstFactorial(int num) {
		int fact=1;
		for(int i=num;i>0;i--) {
			fact=fact*i;
		}
			return fact;
	}

	public static void main(String[] args) {
		Factorial ob=new Factorial();
		int r=ob.FirstFactorial(4);
		System.out.println("Factorial is:"+r);
	}

}
