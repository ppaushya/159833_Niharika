package org.cap.demo;

public class ReplaceCapitalize {
	char[] c;
	public void LetterChanges(String str) {
		c=new char[str.length()];
		for(int i=0;i<str.length();i++) {
			c[i]=str.charAt(i);
		}
		
		for(int i=0;i<str.length();i++) {
			if(c[i]=='Z'||c[i]=='z')
				c[i]-=25;
			else if(c[i]==' ') {
				
			}
			
			else{
				c[i]=(char)(c[i]+1);
			}
			
		}
		for(int i=0;i<str.length();i++) {
			if(c[i]=='a'||c[i]=='e'||c[i]=='i'||c[i]=='o'||c[i]=='u') {
				c[i]-=32;
			}
				
		}
		System.out.println("Ordered String is:");
		System.out.println();
		for(int i=0;i<str.length();i++) {
			System.out.print(c[i]);
		}
	}
	

	public static void main(String[] args) {
		ReplaceCapitalize rc=new ReplaceCapitalize();
		rc.LetterChanges("jdghkb gtdhc");

	}

}
