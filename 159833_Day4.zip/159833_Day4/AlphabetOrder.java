package org.cap.demo;

public class AlphabetOrder {
	char s[];
	public void AlphabetSoup(String str) {
		char a;
		s=new char[str.length()];
		for(int i=0,j=0;i<str.length();i++) {
			s[j]=str.charAt(i);
			System.out.print(s[j]);
			j++;
		}
		System.out.println();
		for(int i=0;i<str.length();i++) {
			for(int j=i+1;j<str.length();j++) {
				if(s[i]>s[j]) {
					a=s[i];
					s[i]=s[j];
					s[j]=a;
				}
			}
		}
		System.out.println("String in Alphabetical order is:");
		for(int i=0;i<str.length();i++) {
			System.out.print(s[i]);
		
		}
		
	}
	public static void main(String[] args) {
		AlphabetOrder ao=new AlphabetOrder();
		//String r=
		ao.AlphabetSoup("ellohxtr");

	}

}
