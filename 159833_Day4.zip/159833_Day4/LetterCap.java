package org.cap.demo;

public class LetterCap {
	char[] c;
	public void LetterCapitalize(String s) {
		c=new char[s.length()];
		for(int i=0;i<s.length();i++) {
			c[i]=s.charAt(i);
		}
		int t=0;
		for(int i=0;i<s.length();i++) {
			if(c[0]<=122&&c[0]>=97)
				c[0]-=32;
			else if(c[i]==' ') {
				if(c[i+1]==' ') {
					t++;
					break;
					
				}
				else if(c[i+1]<=122&&c[i+1]>=97)
					c[i+1]-=32;
			}
		}
		if(t!=0) {
			System.out.println("words should be separated by only one space");
		}
		for(int i=0;i<s.length();i++) {
			System.out.print(c[i]);
		}
		
	}

	public static void main(String[] args) {
		LetterCap obj=new LetterCap();
		obj.LetterCapitalize("this is worst problem");

	}

}