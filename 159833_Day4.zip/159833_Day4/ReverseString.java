package org.cap.demo;

public class ReverseString {
	char c[]; char r[];
	public String ReverseOrder(String str) {
		c=new char[str.length()];
		for(int i=0;i<str.length();i++) {
			c[i]=str.charAt(i);
		}
		r=new char[str.length()];
		for(int i=0,j=str.length()-1;i<str.length();i++,j--) {
			r[j]=c[i];
		}
		String s=new String(r);
		return s;
	}
	public static void main(String[] args) {
		ReverseString rs=new ReverseString();
		String s=rs.ReverseOrder("Hello world");
		System.out.println("Reversed String is "+s);
	}

}
