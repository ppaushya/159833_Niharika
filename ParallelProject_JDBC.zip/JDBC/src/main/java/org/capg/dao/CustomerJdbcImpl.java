package org.capg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Address;
import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.capg.util.Utility;

public class CustomerJdbcImpl implements ICustomerDao{

	@Override
	public List<Customer> getAllCustomers() {
		
		String sql="select * from customer";
		List<Customer> customers=new ArrayList<>();
	
			try(PreparedStatement statement=getDbConnection().prepareStatement(sql)){
				
				ResultSet rs=statement.executeQuery();
				
				while(rs.next()) {
					String[] str=rs.getString(4).split("-");
					customers.add(new Customer(rs.getInt(1),rs.getString(2),rs.getString(3),
							LocalDate.of(Integer.parseInt(str[0]), Integer.parseInt(str[1]),Integer.parseInt(str[2])),
							rs.getString(5),rs.getString(6)));
					
				}
				return customers;
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			
		return null;
	}

	@Override
	public List<Account> getAllAccounts() {
		
		String sql="select * from account";
		List<Account> accounts=new ArrayList<>();
		try {
			PreparedStatement statement=getDbConnection().prepareStatement(sql);
			
			ResultSet rs=statement.executeQuery();
			
			while(rs.next()) {
				String[] str=rs.getString(3).split("-");
				
				accounts.add(new Account(rs.getInt(1),AccountType.valueOf(rs.getString(2)),LocalDate.of(Integer.parseInt(str[0]), Integer.parseInt(str[1]), 
						Integer.parseInt(str[2])),rs.getDouble(4),rs.getString(5),rs.getInt(6)));
			}
			
			} catch (SQLException e) {
				e.printStackTrace();
			}
		
		return accounts;
	}

	@Override
	public void createCustomer(Customer customer) {
		
		
		String sql="insert into customer(firstName,LastName,dateOfBirth,emailId,mobile) values(?,?,?,?,?)";
		String sql1="insert into address values(?,?,?,?,?,?)";
		String sql2="select max(customerId) from customer";
		
		Address address=new Address();
		int count=0;
		int count1=0;
		int custId = 0;
		try(PreparedStatement statement=getDbConnection().prepareStatement(sql)) {

	
			statement.setString(1, customer.getFirstName());
			statement.setString(2, customer.getLastName());
			statement.setDate(3,java.sql.Date.valueOf(customer.getDateOfBirth()));
			statement.setString(4, customer.getEmailId());
			statement.setString(5, customer.getMobile());
			
			count=statement.executeUpdate();
			
			}catch (SQLException e) {
			e.printStackTrace();
			}
		
		try(PreparedStatement statement2=getDbConnection().prepareStatement(sql2)) {
			
			ResultSet rs=statement2.executeQuery();
			
			if(rs.next()) {
				custId=rs.getInt(1);
				System.out.println(custId);
				customer.setCustomerId(custId);
				System.out.println(customer.getCustomerId());
				}
			
			} catch (SQLException e) {
				e.printStackTrace();
				}
			
		try(PreparedStatement statement1=getDbConnection().prepareStatement(sql1)) {
			
			statement1.setInt(1, custId);
			statement1.setString(2, customer.getAddress().getAddressLine1());
			statement1.setString(3, customer.getAddress().getAddressLine2());
			statement1.setString(4, customer.getAddress().getCity());
			statement1.setString(5,customer.getAddress().getState());
			statement1.setString(6, customer.getAddress().getPincode());
			
			count1=statement1.executeUpdate();
			
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			if(count>0) {
				if(count1>0) {
					System.out.println("Customer created successfully!!!");	
				}
			}
	}
	
	
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}

	@Override
	public void addAccount(Account account,int custId) {
		
		String sql="insert into account(accountType,openingDate,openingBalance,description,customerId) values(?,?,?,?,?)";
		int count=0;
		try(PreparedStatement statement=getDbConnection().prepareStatement(sql)) {

			statement.setString(1, account.getAccountType().toString());
			statement.setDate(2,Date.valueOf(account.getOpeningDate()));
			statement.setDouble(3, account.getOpeningBalance());
			statement.setString(4, account.getDescription());
			
			
			statement.setInt(5, custId);
			
			count=statement.executeUpdate();
			
			if(count>0) {
				System.out.println("Account Created Successfully!!!");
				}
			
		}catch (SQLException e) {
				e.printStackTrace();
				}
	}

	@Override
	public List<Transaction> getAllTransactions() {
		
		String sql="select * from transaction";
		List<Transaction> transactions=new ArrayList<>();
		try {
			PreparedStatement statement=getDbConnection().prepareStatement(sql);
			
			ResultSet rs=statement.executeQuery();
			
			while(rs.next()) {
				String[] str=rs.getString(3).split("-");
				
				transactions.add(new Transaction(rs.getInt(1),rs.getString(2),LocalDate.of(Integer.parseInt(str[0]), Integer.parseInt(str[1]), 
						Integer.parseInt(str[2])),rs.getInt(4),rs.getInt(5),rs.getDouble(6),rs.getString(7)));
			}
			
			} catch (SQLException e) {
				e.printStackTrace();
			}
		
		return transactions;
	}

	@Override
	public void addTransaction(Transaction transaction) {
		String sql="insert into transaction(transactionType,transactionDate,fromAccount,toAccount,amount,description) values(?,?,?,?,?,?)";
		int count=0;
		try(PreparedStatement statement=getDbConnection().prepareStatement(sql)) {

			statement.setString(1, transaction.getTransactionType());
			statement.setDate(2,Date.valueOf(transaction.getTransactionDate()));
			statement.setInt(3,transaction.getFromAccount());
			statement.setInt(4, transaction.getToAccount());
			statement.setDouble(5, transaction.getAmount());
			statement.setString(6, transaction.getDescription());
			
			count=statement.executeUpdate();
			
			if(count>0) {
				System.out.println("Transaction Completed Successfully!!!");
				}
			
		}catch (SQLException e) {
				e.printStackTrace();
				}
		
	}

}
