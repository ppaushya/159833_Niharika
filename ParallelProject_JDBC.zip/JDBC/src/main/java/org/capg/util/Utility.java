package org.capg.util;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.service.CustomerServiceImpl;
import org.capg.service.ICustomerService;

public class Utility {
	static Customer customer;
	static ICustomerService customerService=new CustomerServiceImpl();
	
	
	public static boolean isValidName(String name) {
		return name.matches("[a-zA-Z]{3,}");
	}

	
	public static boolean isValidEmail(String email) {
		return email.matches("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
	}
	
	
	public static boolean isValidMobile(String mobile) {
		return mobile.matches("\\d{10}");
	}

	public static boolean isValidDob(String dob) {
		
		return dob.matches("[0,1,2,3]\\d{1}-[0,1]\\d{1}-(18|19|20)\\d{2}");
	}
	
	public static boolean isValidPincode(String pincode) {
		return pincode.matches("\\d{6}");
	}

	public static long generateAccountNo() {
		return (long)(Math.random()*100000);
	}

	public static boolean isValidBalance(double balance) {
		if(balance>1000)
			return true;
		else
		return false;
	}

	

	public static Customer isValidCustomer(int custId) {
		List<Customer> customers=customerService.getAllCustomers();
		Customer customer=new Customer();
	
			for(Customer cust:customers) {
				if(cust.getCustomerId()==custId)
				{
					return cust;
				}
			}
	
		return null;
		
	}
	public static int doesCustomerHasAccount(int custId) {
		List<Account> accounts=customerService.getAllAccounts();
		
		for(Account acc:accounts)
				{
					if(acc.getCustomerId()==custId) {
						return custId;
					}
					
				}
			
		return 0;
		
	}

	public static Account isValidAccount(int custId,long accNo) {
		List<Account> accounts=customerService.getAllAccounts();
		for(Account acc:accounts){
			if(custId==acc.getCustomerId()) {
				if(accNo==acc.getAccountNumber()) {
					return acc;
				}
			}

		}
		return null;
	}

	public static Account isValidToAccount(int toAccountNumber) {
		List<Customer> customers=customerService.getAllCustomers();
		
		for(Customer customer:customers) {
			List<Account> accounts=customerService.getAllAccounts();
			for(Account account:accounts) {
				if(account.getAccountNumber()==toAccountNumber)
					return account;
			}
		}
		
		return null;
	}

}
