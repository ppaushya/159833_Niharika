package org.capg.boot;

import java.sql.ResultSet;
import java.util.List;
import java.util.Scanner;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.capg.service.CustomerServiceImpl;
import org.capg.service.ICustomerService;
import org.capg.util.Utility;
import org.capg.view.UserInteraction;

public class Boot {
static Scanner scanner=new Scanner(System.in);
	
	public static void main(String[] args) {
		ICustomerService customerService=new CustomerServiceImpl();
		UserInteraction userInteraction=new UserInteraction();
		
		int  choice;
		String option;
		do {
		System.out.println("1.Create Customer");
		System.out.println("2.List Customers");
		System.out.println("Enter Your choice:");
		choice=scanner.nextInt();
				
			switch(choice) {		
			case 1:
				Customer customer=userInteraction.getCustomerDetails();
				customerService.createCustomer(customer);
				System.out.println(customer);
				break;
			case 2:
				
				List<Customer> customers= customerService.getAllCustomers();
				userInteraction.printCustomers(customers);
				int custId;
				Customer cust;
				do {
				System.out.println("Enter customer Id");
				int customerId=scanner.nextInt();
				cust=Utility.isValidCustomer(customerId);
				custId=cust.getCustomerId();
				if(custId!=0) {
					System.out.println("Enter your choice");
					System.out.println("1.Create Account");
					System.out.println("2. Deposit/Withdraw");
					System.out.println("3. Funds Transfer");
					System.out.println("4. Account Summary");
					int sel=scanner.nextInt();
					switch(sel) {
					case 1:
						Account account=userInteraction.getAccountDetails(custId);
						customerService.addAccount(account, custId);
						
						break;
					case 2:
						if(Utility.doesCustomerHasAccount(custId)!=0) {
							Transaction transaction=userInteraction.creditDebit(custId);
							customerService.addTransaction(transaction);
						}
						else {
							System.out.println("Customer Doesn't have any account!!Please create new account");
						}
											
						break;
					case 3:
						if(Utility.doesCustomerHasAccount(custId)!=0) {
							Transaction transaction=userInteraction.fundsTransfer(custId);
							customerService.addTransaction(transaction);
						}
						else {
							System.out.println("Customer Doesn't have any account!!Please create new account");
						}
						break;
					case 4:
						if(Utility.doesCustomerHasAccount(custId)!=0) {
						List<Transaction> accountSummary=userInteraction.printTransactions(custId);
						for(Transaction trans:accountSummary) {
							System.out.println(trans);
						}
						
						}
						
						break;
					default:
						System.out.println("Sorry! Invalid Choice");
						System.exit(0);
					
					}				
				}
							
				else 
				System.out.println("Enter valid customer Id");
			
					
				}while(custId==0);
				break;
			
			default:
				System.out.println("Sorry! Invalid Choice");
				System.exit(0);
		}
			System.out.println("Do you wish to contine?[y|n]:");
			option=scanner.next();		
							
		}while(option.charAt(0)=='y' || option.charAt(0)=='Y');
		
	
	}


}
