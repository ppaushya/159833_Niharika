package org.util;

public class Utility {

	
	public boolean validateName(String customerName) {
		
		if(customerName.matches("[A-Z]{1}[a-zA-Z/s]+"))
			return true;
		else 
			System.out.println("Enter valid name");
			return false;
	}

	public boolean validateMobileNo(String mobileNo) {
		
		if(mobileNo.matches("[0-9]{10}"))
			return true;
		else 
			System.out.println("Enter valid number");
		return false;
	
	}

}
