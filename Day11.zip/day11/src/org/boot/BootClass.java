package org.boot;

import java.util.Scanner;

import org.exception.IllegalCustomerException;
import org.exception.InvalidAgeException;
import org.exception.InvalidMobileNoException;
import org.model.Registration;
import org.service.IRegistrationService;
import org.service.RegistrationServiceImpl;
import org.view.UserInteraction;

public class BootClass {
	static Scanner scanner=new Scanner(System.in);
	
	public static void main(String args[]) throws IllegalCustomerException, InvalidMobileNoException, InvalidAgeException {
		UserInteraction userInteraction=new UserInteraction();
		IRegistrationService service=new RegistrationServiceImpl();
		
		do {
			System.out.println("Enter your choice:\n1.Registration/n2.Exit");
			byte choice=scanner.nextByte();
			switch(choice) {
			case 1:
				Registration register=userInteraction.registration();
				Registration registeredPlayer=service.addPlayer(register);
				System.out.println(registeredPlayer);
				break;
			case 2:
				System.exit(0);
			}
		
		}while(true);
		
	}

}
