package org.exception;

public class IllegalCustomerException extends Exception {
	
	public IllegalCustomerException (String msg) {
		super(msg);
	}

}
