package org.exception;

public class InvalidMobileNoException extends Exception {
	
	public InvalidMobileNoException(String msg) {
		super(msg);
		}

}
