package org.service;

import org.exception.IllegalCustomerException;
import org.exception.InvalidAgeException;
import org.exception.InvalidMobileNoException;
import org.model.Registration;

public interface IRegistrationService {

	public Registration addPlayer(Registration register) throws IllegalCustomerException, InvalidMobileNoException, InvalidAgeException;
	
	

}
