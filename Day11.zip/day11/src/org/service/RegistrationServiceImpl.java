package org.service;

import org.dao.IRegistrationDao;
import org.dao.RegistrationDaoImpl;
import org.exception.InvalidAgeException;
import org.exception.InvalidMobileNoException;
import org.model.Registration;

public class RegistrationServiceImpl implements IRegistrationService{

		IRegistrationDao registrationDao= new RegistrationDaoImpl();
		
		
	@Override
	public Registration addPlayer(Registration register) throws InvalidMobileNoException, InvalidAgeException {

		if(register.getMobileNo().matches("[789]//d{9}")) 
			throw new InvalidMobileNoException("Invalid mobile number");
		if(register.getAge()>0&&register.getAge()<100)
			throw new InvalidAgeException("Invalid Age!!!");
		
		if(register.getAge()<18)
			register.setActualRegFeePaid(register.getRegistrationFees());
		else if(register.getAge()>=18&&register.getAge()<25)
			register.setActualRegFeePaid((float)(register.getRegistrationFees()*1.1));
		else if(register.getAge()>=25&&register.getAge()<50)
			register.setActualRegFeePaid((float)(register.getRegistrationFees()*1.2));
		else
			register.setActualRegFeePaid((float)(register.getRegistrationFees()*1.3));
		
		
		if(registrationDao.addPlayer(register)!=null)
			return register;
		else 
			return null;
		
		
	}

	
	
	
	
}
