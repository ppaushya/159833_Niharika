package org.dao;



import org.model.Registration;

public class RegistrationDaoImpl implements IRegistrationDao{

	@Override
	public void addPlayer(Registration register) {
		String sql="insert into player values(?,?,?,?,?)";
		
		try(Connection conn=getDbConnection()) {
			
			PreparedStatement statement=conn.prepareStatement(sql);
			statement.setString(1, register.getCustomerName());
			statement.setString(2, register.getMobileNo());
			statement.setFloat(3, register.getRegistrationFees());
			statement.setByte(4, register.getAge());
			statement.setFloat(5,register.getActualRegFeePaid());
			
			
			int count=statement.executeUpdate();
			
			if(count>0)
				System.out.println("Insertion done!");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
	
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}



}
