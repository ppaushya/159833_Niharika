package org.dao;

import org.model.Registration;

public interface IRegistrationDao {

	public Registration addPlayer(Registration register);
	

}
