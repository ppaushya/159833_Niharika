package org.model;

public class Registration {

	private int registrationId;
	private String customerName;
	private String mobileNo;
	private float registrationFees;
	private byte age;
	private float actualRegFeePaid;
	
	public Registration() {
		super();
	}
	
	public Registration(String customerName, String mobileNo, float registrationFees, byte age, float actualRegFeePaid) {
		super();
		this.customerName = customerName;
		this.mobileNo = mobileNo;
		this.registrationFees = registrationFees;
		this.age = age;
		this.actualRegFeePaid = actualRegFeePaid;
	}
	
	public int getRegistrationId() {
		return registrationId;
	}
	
	public void setRegistrationId(int registrationId) {
		this.registrationId = registrationId;
	}
	
	public String getCustomerName() {
		return customerName;
	}
	
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	public String getMobileNo() {
		return mobileNo;
	}
	
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	
	public float getRegistrationFees() {
		return registrationFees;
	}
	
	public void setRegistrationFees(float registrationFees) {
		this.registrationFees = registrationFees;
	}
	
	public byte getAge() {
		return age;
	}
	
	public void setAge(byte age) {
		this.age = age;
	}
	
	public float getActualRegFeePaid() {
		return actualRegFeePaid;
	}
	
	public void setActualRegFeePaid(float actualRegFeePaid) {
		this.actualRegFeePaid = actualRegFeePaid;
	}
	
	@Override
	public String toString() {
		return "Registration [registrationId=" + registrationId + ", customerName=" + customerName + ", mobileNo="
				+ mobileNo + ", registrationFees=" + registrationFees + ", age=" + age + ", actualRegFeePaid="
				+ actualRegFeePaid + "]";
	}
	
	
}
