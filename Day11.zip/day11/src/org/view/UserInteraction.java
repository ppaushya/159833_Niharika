package org.view;

import java.util.Scanner;

import org.model.Registration;
import org.service.RegistrationServiceImpl;
import org.util.Utility;

public class UserInteraction {
	static Scanner scanner=new Scanner(System.in);
	Utility utility=new Utility();
	Registration register;
	
	
	public Registration registration() {
		
		
		register=new Registration();
		register.setCustomerName(promptCustomerName());
		register.setMobileNo(promptMobileNo());
		register.setRegistrationFees(promptRegistrationFees());
		register.setAge(promptAge());
		
		return register;
		
	}
	
	private byte promptAge() {
		System.out.println("Enter Age greater than 0");
		byte age=scanner.nextByte();
		return age;
	}

	private float promptRegistrationFees() {
		
		System.out.println("Enter registration fees greater than 0");
		float registrationFees=scanner.nextFloat();
		return registrationFees;
	}

	private String promptMobileNo() {
		String mobileNo;
		boolean flag;
		System.out.println("Enter mobile number");
		do {
			mobileNo=scanner.next();
			flag=utility.validateMobileNo(mobileNo);
		}while(!flag);
		
		return mobileNo;
	}

	public String promptCustomerName() {
		boolean flag=false;
		System.out.println("Enter your name");
		String customerName;
		do {
			customerName=scanner.next();
			flag=utility.validateName(customerName);
		}while(!flag);
		
		return customerName; 
	}

}
